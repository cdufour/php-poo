<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>My Gallery - Admin</title>
    <link href="<?= ASSETS_PATH ?>/css/bootstrap.min.css" rel="stylesheet">
    <link href="<?= ASSETS_PATH ?>/css/admin.css" rel="stylesheet">
    <link href="<?= ASSETS_PATH ?>/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
</head>

<body>
    <div id="wrapper">
