<?php require_once("../includes/boot.php"); ?>
<?php include("layouts/header.php"); ?>

        <div class="row">
            <div class="col-md-8"></div>
            <div class="col-md-4">
              <?php include("layouts/sidebar.php"); ?>
            </div>
        <!-- /.row -->

        <?php include("layouts/footer.php"); ?>
